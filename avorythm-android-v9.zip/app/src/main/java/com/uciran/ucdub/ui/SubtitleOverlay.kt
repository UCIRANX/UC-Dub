package com.uciran.ucdub.ui

import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.uciran.ucdub.data.TranscriptEntry

/**
 * Floating subtitles over other apps. Only the text itself has a translucent background:
 * one line for the original speech and one for the translation. Each new chunk replaces
 * the previous one. Requires the "display over other apps" permission.
 */
class SubtitleOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var sourceView: TextView? = null
    private var translatedView: TextView? = null

    fun canShow(): Boolean = Settings.canDrawOverlays(context)

    fun show() {
        main.post {
            if (root != null || !canShow()) return@post
            val src = makeText(0xFFFFFFFF.toInt())
            val tr = makeText(0xFFFFE082.toInt())
            val container = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                // No background here: empty rows are hidden, so nothing shows until there is text.
                addView(src)
                addView(tr)
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM
                y = dp(60)
            }
            windowManager.addView(container, params)
            root = container
            sourceView = src
            translatedView = tr
        }
    }

    /** Shows the latest chunk: the original and its translation. */
    fun update(items: List<TranscriptEntry>) {
        main.post {
            val src = sourceView ?: return@post
            val tr = translatedView ?: return@post
            val latest = items.lastOrNull()
            setText(src, latest?.source.orEmpty())
            setText(tr, latest?.translated.orEmpty())
        }
    }

    private fun makeText(color: Int): TextView = TextView(context).apply {
        textSize = 16f
        setTextColor(color)
        gravity = Gravity.CENTER
        maxLines = 3
        setBackgroundColor(0xB0000000.toInt())
        setPadding(dp(10), dp(4), dp(10), dp(4))
        visibility = View.GONE
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(2) }
    }

    private fun setText(view: TextView, value: String) {
        if (value.isBlank()) {
            view.visibility = View.GONE
            return
        }
        view.text = value
        view.visibility = View.VISIBLE
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun hide() {
        main.post {
            root?.let { windowManager.removeView(it) }
            root = null
            sourceView = null
            translatedView = null
        }
    }
}
